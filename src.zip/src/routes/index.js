const express = require('express');
const router = express.Router();
const reviewerController = require('../controllers/reviewer.controller');
const makananController = require('../controllers/makanan.controller');

router.get('/reviewer', reviewerController.daftarreviewer);
router.post('/reviewer', reviewerController.tambahreviewer);
router.put('/reviewer/:id', reviewerController.ubahreviewer);
router.delete('/reviewer/:id', reviewerController.hapusreviewer);
router.get('/reviewer/:id', reviewerController.detailreviewer);

router.get('/makanan', makananController.daftarmakanan);
router.post('/makanan', makananController.tambahmakanan);
router.put('/makanan/:id', makananController.ubahmakanan);
router.delete('/makanan/:id', makananController.hapusmakanan);
router.get('/makanan/:id', makananController.detailmakanan);

module.exports = router;
