'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class reviewer extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      reviewer.hasMany(models.makanan, {
        foreignKey: 'reviewer_id'
      })
      // define association here
    }
  }
  reviewer.init({
    Nama: DataTypes.STRING,
    Umur: DataTypes.INTEGER,
    domisili: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'reviewer',
    tableName: 'reviewer'
  });
  return reviewer;
};