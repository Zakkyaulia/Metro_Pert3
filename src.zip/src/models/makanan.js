'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class makanan extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      makanan.belongsTo(models.reviewer, {
        foreignKey: 'reviewer_id',
      })
      // define association here
    }
  }
  makanan.init({
    nama: DataTypes.STRING,
    reviewer_id: DataTypes.INTEGER,
    deskripsi: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'makanan',
    tableName: 'makanan'
  });
  return makanan;
};