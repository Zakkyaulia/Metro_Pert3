
const {makanan} = require('../models')
const reviewer = require('../models/reviewer')


const daftarmakanan = async (req, res) => {

    try{
        const makanans = await makanan.findAll(
            {
                include: reviewer
            }
    )
        res.status(200).json({
            "message": "Berhasil mendapatkan daftar makanan",
            "data" : makanans
        })
    } catch (error) {
        res.status(500).json({
            "message": "Gagal mendapatkan daftar makanan",
            "error" : error
        })
        console.log(error)
    }
}

const tambahmakanan= async (req, res) => {
    try {
        const makanans = await makanan.create(req.body)
        res.status(201).json({
            "message" : "Berhasil menambahkan makanan",
            "data" : makanans
        })
    }catch (error) {
        res.status(500).json({
            "message" : "Gagal menambahkan makanan",
            "error": error
        })
        console.log(error)
    }
}

const hapusmakanan = async (req, res) => {
    try{
        const makanans = await makanan.destroy({
        where: {
            id: req.params.id
        }
        })
        res.status(201).json({
            "message": "Berhasil menghapus makanan",
            "data": makanans
        })
    }catch(error){
        res.status(500).json({
            "message": "Gagal menghapus makanan",
            "error": error
        })
        console.log(error)
    }
}

const ubahmakanan = async (req,res) => {

    try {
        const makanans = await makanan.update(req.body, {
            where: {
                id: req.params.id
            }
        })
        res.status(201).json({
            "message": "Berhasil mengubah makanan",
            "data": makanans
        })
    }
    catch(error){
        res.status(500).json({
            "message": "Gagal mengubah makanan",
            "error": error
        })
        console.log(error)
    }
}

const detailmakanan = async (req, res) => {
    try{
        const {id} = req.params
        const makanans = await makanan.findByPk(id)
        res.status(201).json({
            "message" : "Berhasil mendapatkan makanan",
            "data": makanans
        })
    }
    catch(error){
        res.status(500).json({
            "message": "Gagal mendapatkan makanan",
            "error": error
        })
        console.log(error)
    }
}

module.exports = {
    daftarmakanan,
    tambahmakanan,
    hapusmakanan,
    ubahmakanan,
    detailmakanan
}
