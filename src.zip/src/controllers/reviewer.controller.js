const { where } = require('sequelize')
const {reviewer} = require('../models')


const daftarreviewer = async (req, res) => {

    try{
        const reviewers = await reviewer.findAll()
        res.status(200).json({
            "message": "Berhasil mendapatkan daftar reviewer",
            "data" : reviewers
        })
    } catch (error) {
        res.status(500).json({
            "message": "Gagal mendapatkan daftar reviewer",
            "error" : error
        })
        console.log(error)
    }
}

const tambahreviewer= async (req, res) => {
    try {
        const reviewers = await reviewer.create(req.body)
        res.status(201).json({
            "message" : "Berhasil menambahkan reviewer",
            "data" : reviewers
        })
    }catch (error) {
        res.status(500).json({
            "message" : "Gagal menambahkan reviewer",
            "error": error
        })
        console.log(error)
    }
}

const hapusreviewer = async (req, res) => {
    try{
        const reviewers = await reviewer.destroy({
        where: {
            id: req.params.id
        }
        })
        res.status(201).json({
            "message": "Berhasil menghapus reviewer",
            "data": reviewers
        })
    }catch(error){
        res.status(500).json({
            "message": "Gagal menghapus reviewer",
            "error": error
        })
        console.log(error)
    }
}

const ubahreviewer = async (req,res) => {

    try {
        const reviewers = await reviewer.update(req.body, {
            where: {
                id: req.params.id
            }
        })
        res.status(201).json({
            "message": "Berhasil mengubah reviewer",
            "data": reviewers
        })
    }
    catch(error){
        res.status(500).json({
            "message": "Gagal mengubah reviewer",
            "error": error
        })
        console.log(error)
    }
}

const detailreviewer = async (req, res) => {
    try{
        const {id} = req.params
        const reviewers = await reviewer.findByPk(id)
        res.status(201).json({
            "message" : "Berhasil mendapatkan reviewer",
            "data": reviewers
        })
    }
    catch(error){
        res.status(500).json({
            "message": "Gagal mendapatkan reviewer",
            "error": error
        })
        console.log(error)
    }
}

module.exports = {
    daftarreviewer,
    tambahreviewer,
    hapusreviewer,
    ubahreviewer,
    detailreviewer
}
